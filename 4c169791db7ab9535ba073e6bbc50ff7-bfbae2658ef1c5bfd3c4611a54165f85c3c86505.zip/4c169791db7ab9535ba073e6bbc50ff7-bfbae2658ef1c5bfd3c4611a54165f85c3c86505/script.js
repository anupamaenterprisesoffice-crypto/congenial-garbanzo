// FIREBASE
const firebaseConfig = {
  apiKey: "AIzaSyApLpqXTnuPsT5rdDG04jLMlW-a0ERkbpM",
  databaseURL: "https://stockgameultra-default-rtdb.firebaseio.com",
  storageBucket: "stockgameultra.firebasestorage.app"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const storage = firebase.storage();

let currentUser = localStorage.getItem("user");

// AUTO LOGIN
if (currentUser) startApp();

// AUTH
function signup(){
  db.ref("users/"+username.value).set({password:password.value});
  alert("Account created");
}

function login(){
  db.ref("users/"+username.value).once("value").then(s=>{
    let d=s.val();
    if(d && d.password===password.value){
      localStorage.setItem("user",username.value);
      currentUser=username.value;
      startApp();
    } else alert("Wrong login");
  });
}

function startApp(){
  auth.style.display="none";
  app.style.display="block";
  loadApps();
}

// LOGOUT
function logout(){
  localStorage.removeItem("user");
  location.reload();
}

// DELETE ACCOUNT
function deleteAccount(){
  db.ref("users/"+currentUser).remove();
  logout();
}

// LOAD APPS
function loadApps(){
  db.ref("apps").on("value",snap=>{
    let data=snap.val();
    if(!data)return;

    let arr=Object.entries(data);
    renderApps(arr);
  });
}

// RENDER
function renderApps(arr){
  apps.innerHTML="";
  arr.forEach(([id,app])=>{
    apps.innerHTML+=`
      <div class="appCard" onclick="openApp('${id}')">
        <img src="${app.icon}">
        <p>${app.name}</p>
        ${app.verified?"✅":""}
      </div>`;
  });
}

// OPEN APP
function openApp(id){
  db.ref("apps/"+id).once("value").then(s=>{
    let a=s.val();

    home.style.display="none";
    appPage.style.display="block";

    appPage.innerHTML=`
      <img src="${a.icon}" width="100">
      <h2>${a.name} ${a.verified?"✅":""}</h2>

      <button onclick="scanAndInstall('${id}','${a.url}')">Install</button>

      <div class="progress"><div id="bar"></div></div>

      <h3>Screenshots</h3>
      <div class="scroll">
        ${(a.screenshots||[]).map(s=>`<img src="${s}">`).join("")}
      </div>

      ${currentUser==="Virat"?`<button onclick="verify('${id}')">Verify</button>`:""}

      <button onclick="back()">Back</button>
    `;
  });
}

// 🔍 SCAN SYSTEM
function scanAndInstall(id,url){
  let risky = Math.random() < 0.4; // 40% risky

  if(!risky){
    animateInstall(id,url);
  } else {
    let choice = confirm("⚠️ This APK may be unsafe.\nPress OK to Download Anyway\nPress Cancel to Cancel");

    if(choice){
      animateInstall(id,url);
    } else {
      alert("Download cancelled");
    }
  }
}

// INSTALL ANIMATION
function animateInstall(id,url){
  let bar=document.getElementById("bar");
  let w=0;

  let i=setInterval(()=>{
    w+=5;
    bar.style.width=w+"%";

    if(w>=100){
      clearInterval(i);
      window.open(url);

      db.ref("apps/"+id+"/downloads").transaction(n=>(n||0)+1);
    }
  },100);
}

// VERIFY ADMIN
function verify(id){
  if(currentUser==="Virat"){
    db.ref("apps/"+id+"/verified").set(true);
    alert("Verified!");
  }
}

// UPLOAD
function uploadAPK(){
  let file=fileInput.files[0];
  let ref=storage.ref("apks/"+file.name);

  ref.put(file).then(s=>{
    s.ref.getDownloadURL().then(url=>{
      db.ref("apps").push({
        name:appName.value,
        icon:appIcon.value,
        url,
        downloads:0,
        verified:false,
        screenshots:[appIcon.value]
      });
      alert("Uploaded!");
    });
  });
}

// NAV
function showHome(){
  home.style.display="block";
  appPage.style.display="none";
}

function showUpload(){
  home.style.display="none";
  upload.style.display="block";
}

function back(){
  showHome();
}